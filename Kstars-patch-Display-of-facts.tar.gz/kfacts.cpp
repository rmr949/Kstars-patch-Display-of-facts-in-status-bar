#include "kfacts.h"

#include <QtCore/QFile>
#include <QtGui/QCheckBox>
#include <QtGui/QKeyEvent>
#include <QtGui/QLabel>
#include <QtGui/QLayout>

#include <kaboutdata.h>
#include <kconfig.h>
#include <kdebug.h>
#include <kglobalsettings.h>
#include <kcomponentdata.h>
#include <klocale.h>
#include <kpushbutton.h>
#include <krandom.h>
#include <kseparator.h>
#include <kstandarddirs.h>
#include <ktextbrowser.h>

class KFactDatabase::Private
{
  public:
    void loadTips( const QString &tipFile );
    void addTips( const QString &tipFile );

    QStringList tips;
    int currentTip;
};

void KFactDatabase::Private::loadTips( const QString &tipFile )
{
  tips.clear();
  addTips( tipFile );
}

void KFactDatabase::Private::addTips( const QString &tipFile )
{
  QString fileName = KStandardDirs::locate( "data", tipFile );

  if ( fileName.isEmpty() ) {
    kDebug() << "KTipDatabase::addTips: can't find '" << tipFile << "' in standard dirs";
    return;
  }

  QFile file( fileName );
  if ( !file.open( QIODevice::ReadOnly ) ) {
    kDebug() << "KTipDatabase::addTips: can't open '" << fileName << "' for reading";
    return;
  }

  QByteArray data = file.readAll();
  QString content = QString::fromUtf8( data.constData(), data.size() );
  const QRegExp rx( "\\n+" );

  int pos = -1;
  while ( ( pos = content.indexOf( "<html>", pos + 1, Qt::CaseInsensitive ) ) != -1 ) {
    /**
     * To make translations work, tip extraction here must exactly
     * match what is done by the preparetips script.
     */
    QString tip = content
           .mid( pos + 6, content.indexOf( "</html>", pos, Qt::CaseInsensitive ) - pos - 6 )
           .replace( rx, "\n" );

    if ( !tip.endsWith( '\n' ) )
      tip += '\n';

    if ( tip.startsWith( '\n' ) )
      tip = tip.mid( 1 );

    if ( tip.isEmpty() ) {
      kDebug() << "Empty tip found! Skipping! " << pos;
      continue;
    }

    tips.append( tip );
  }

  file.close();
}

KFactDatabase::KFactDatabase( const QString &_tipFile )
  : d( new Private )
{
  QString tipFile = _tipFile;

  if ( tipFile.isEmpty() )
    tipFile = KGlobal::mainComponent().aboutData()->appName() + "/tips";

  d->loadTips( tipFile );

  if ( !d->tips.isEmpty() )
    d->currentTip = KRandom::random() % d->tips.count();
}

KFactDatabase::KFactDatabase( const QStringList& tipsFiles )
  : d( new Private )
{
  if ( tipsFiles.isEmpty() || ( ( tipsFiles.count() == 1 ) && tipsFiles.first().isEmpty() ) ) {
    d->addTips( KGlobal::mainComponent().aboutData()->appName() + "/tips" );
  } else {
    for ( QStringList::ConstIterator it = tipsFiles.begin(); it != tipsFiles.end(); ++it )
      d->addTips( *it );
  }

  if ( !d->tips.isEmpty() )
    d->currentTip = KRandom::random() % d->tips.count();
}

KFactDatabase::~KFactDatabase()
{
    delete d;
}

void KFactDatabase::nextFact()
{
  if ( d->tips.isEmpty() )
    return;

  d->currentTip += 1;

  if ( d->currentTip >= (int) d->tips.count() )
    d->currentTip = 0;
}


QString KFactDatabase::fact() const
{
  if ( d->tips.isEmpty() )
    return QString();

  return d->tips[ d->currentTip ];
}



