#include <QtCore/QStringList>

class KFactDatabase
{
  public:
    
    explicit KFactDatabase( const QString &tipFile = QString() );

     
    explicit KFactDatabase( const QStringList &tipFiles );

    ~KFactDatabase();

    
    QString fact() const;

    
    void nextFact();

    

  private:
    class Private;
    Private* const d;
};


